.. _api_documentation:

=================
API Documentation
=================

.. currentmodule:: pyldpc

code
====

Functions

.. autosummary::
   :toctree: generated/

   make_ldpc
   encode
   decode
