pyldpc.decode
=============

.. currentmodule:: pyldpc

.. autofunction:: decode