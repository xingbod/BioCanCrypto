pyldpc.encode
=============

.. currentmodule:: pyldpc

.. autofunction:: encode