pyldpc.make\_ldpc
=================

.. currentmodule:: pyldpc

.. autofunction:: make_ldpc