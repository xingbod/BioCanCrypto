.. _general_examples:

General examples
================

Introductory examples.
